import numpy as np
from sklearn.model_selection import KFold
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import cross_val_score

def kfold_accuracies(model, X, y):
    cv = KFold(n_splits = 5, random_state = 1, shuffle = True)
    scores = cross_val_score(model, X, y, scoring = 'accuracy', cv = cv, n_jobs = -1)
    return scores



def create_classifier():
    random_forest = RandomForestClassifier(n_estimators = 50)
    return random_forest