#  IN THE NAME OF ALLAH

import numpy as np

class Linear_Regression:
    def __init__(self):
        self.x = 0
        self.y = 0
        self.alpha0 = 0
        self.alpha1 = 0
        self.coefficients = [self.alpha0, self.alpha1]
    
    def fit(self, x, y):
        self.x = np.array(x)
        self.y = np.array(y)
        
        n = np.size(x) 
        m_x, m_y = np.mean(x), np.mean(y)     
        SS_xy = np.sum(y*x) - n*m_y*m_x 
        SS_xx = np.sum(x*x) - n*m_x*m_x           
        self.alpha1 = SS_xy / SS_xx 
        self.alpha0 = m_y - self.alpha1*m_x

#         self.alpha1 = np.cov(self.x, self.y)[0][1] / self.x.var()
#         self.alpha0 = self.y.mean() - self.alpha1 * self.x.mean()
        
        self.coefficients = [self.alpha0, self.alpha1]
        return self
    
    def predict(self, x):
        predictions = list()
        
        for value in x:
            predictions.append(self.alpha0 + self.alpha1 * value)
            
        return predictions
    
    def mean_squared_error(self, y_test, y_pred):
        y_test = np.array(y_test)
        y_pred = np.array(y_pred)
        return np.mean((y_test - y_pred) ** 2)