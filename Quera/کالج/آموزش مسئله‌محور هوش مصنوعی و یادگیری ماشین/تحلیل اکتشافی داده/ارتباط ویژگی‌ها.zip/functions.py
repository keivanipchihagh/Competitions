import numpy as np
from numpy import unravel_index

def max_corr(dataframe):
    correlations = dataframe.corr().abs()
    max_corr = correlations.unstack().sort_values(ascending = False)[len(correlations.columns):]
    return set(max_corr.index[0])