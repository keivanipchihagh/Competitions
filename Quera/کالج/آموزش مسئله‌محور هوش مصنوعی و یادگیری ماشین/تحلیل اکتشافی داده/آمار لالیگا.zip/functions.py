import pandas as pd


def min_points(df_laliga,season):
    record = df_laliga[df_laliga['season'] == season].sort_values(by = 'points', ascending = True).iloc[0]
    return record[['club', 'points']].to_dict()


def max_points(df_laliga,season):
    record = df_laliga[df_laliga['season'] == season].sort_values(by = 'points', ascending = False).iloc[0]
    return record[['club', 'points']].to_dict()