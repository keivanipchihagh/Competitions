import pandas as pd
import numpy as np

def survival_chance(titanic_df,start_age,end_age):
    titanic_df = titanic_df[~titanic_df['Age'].isna()]
    
    records = titanic_df[(titanic_df['Age'] >= start_age) & (titanic_df['Age'] <= end_age)]
    
    male = records[records['Sex'] == 'male']
    male_count = len(male)
    survived_male = male[male['Survived'] == 1]
    survived_male_count = len(survived_male)
    male_survival = -1
    if len(male) != 0: male_survival = survived_male_count / male_count    
    
    female = records[records['Sex'] == 'female']
    female_count = len(female)
    survived_female = female[female['Survived'] == 1]
    survived_female_count = len(survived_female)
    female_survival = -1
    if len(female) != 0: female_survival = survived_female_count / female_count
    
    return {'male': float('{:.3f}'.format(male_survival)),
              'female': float('{:.3f}'.format(female_survival))}