import numpy as np
def is_normal(boys_df,girls_df,age_in_days,height_in_cm,gender):
    P15, P85 = None, None
    
    if gender == 'male':
        record = boys_df[boys_df['Day'] == age_in_days]        
    else:
        record = girls_df[boys_df['Day'] == age_in_days]
    
    P15, P85 = float(record['P15']), float(record['P85'])
        
    return P15 <= height_in_cm < P85